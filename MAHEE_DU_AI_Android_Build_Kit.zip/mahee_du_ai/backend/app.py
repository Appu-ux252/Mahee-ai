import os
from typing import Literal
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
from pydantic import BaseModel, Field

app = FastAPI(title="MAHEE DU AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Development only; restrict in production.
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

Language = Literal["en-US", "si-LK", "ta-LK"]

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)
    language: Language = "en-US"

class ChatResponse(BaseModel):
    reply: str

SYSTEM_PROMPT = (
    "You are MAHEE DU, a friendly personal AI assistant with a warm, natural voice. "
    "Respond in the requested language: en-US means English, si-LK means Sinhala, "
    "ta-LK means Tamil. Follow the user's language when clear. Be concise and honest. "
    "Never claim you placed a call, sent a message, opened an app, or changed settings "
    "unless a real integration confirms it. Ask for confirmation before external actions "
    "that contact people or share private information."
)

@app.get("/health")
def health():
    return {"status": "ok", "service": "MAHEE DU AI"}

@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    api_key = os.getenv("OPENAI_API_KEY")
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    if not api_key:
        raise HTTPException(status_code=503, detail="Backend is missing OPENAI_API_KEY.")
    try:
        client = OpenAI(api_key=api_key)
        result = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Requested locale: {request.language}\n\n{request.message}"},
            ],
            temperature=0.7,
        )
        reply = result.choices[0].message.content or "Sorry, I could not form a reply."
        return ChatResponse(reply=reply)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"AI provider request failed: {type(exc).__name__}")
