import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() => runApp(const MaheeDuApp());

class MaheeDuApp extends StatelessWidget {
  const MaheeDuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'MAHEE DU AI',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7657E8)), useMaterial3: true),
    home: const AssistantPage(),
  );
}

class ChatMessage {
  final String role;
  final String text;
  const ChatMessage({required this.role, required this.text});
}

class AssistantPage extends StatefulWidget {
  const AssistantPage({super.key});
  @override
  State<AssistantPage> createState() => _AssistantPageState();
}

class _AssistantPageState extends State<AssistantPage> {
  // Android emulator: http://10.0.2.2:8000
  // Physical phone: use your computer LAN IP. Keep API keys on backend only.
  static const String backendBaseUrl = 'http://127.0.0.1:8000';

  final _input = TextEditingController();
  final _scroll = ScrollController();
  final _speech = stt.SpeechToText();
  final _tts = FlutterTts();
  final List<ChatMessage> _messages = [
    const ChatMessage(role: 'assistant', text: 'Ayubowan! Vanakkam! Hello! I am MAHEE DU. How can I help you?')
  ];
  final Map<String, String> _languages = {'English': 'en-US', 'Sinhala': 'si-LK', 'Tamil': 'ta-LK'};
  String _localeId = 'en-US';
  bool _listening = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _configureTts();
  }

  Future<void> _configureTts() async {
    await _tts.setSpeechRate(0.46);
    await _tts.setPitch(1.08);
    await _tts.setVolume(1.0);
    await _tts.setLanguage(_localeId);
  }

  Future<void> _changeLanguage(String? locale) async {
    if (locale == null) return;
    setState(() => _localeId = locale);
    await _tts.setLanguage(locale);
  }

  Future<void> _startListening() async {
    if (_busy) return;
    final available = await _speech.initialize(
      onStatus: (status) {
        if (status == 'notListening' && mounted) setState(() => _listening = false);
      },
      onError: (error) {
        if (!mounted) return;
        setState(() => _listening = false);
        _show('Speech error: ${error.errorMsg}');
      },
    );
    if (!available) {
      _show('Speech recognition is unavailable. Check microphone permission and device language support.');
      return;
    }
    setState(() => _listening = true);
    await _speech.listen(
      localeId: _localeId,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      onResult: (result) {
        if (mounted) setState(() => _input.text = result.recognizedWords);
      },
    );
  }

  Future<void> _stopListening() async {
    await _speech.stop();
    if (mounted) setState(() => _listening = false);
  }

  Future<String?> _localCommand(String prompt) async {
    final lower = prompt.toLowerCase().trim();
    if (lower == 'stop speaking' || lower == 'stop voice') {
      await _tts.stop();
      return 'Okay, I stopped speaking.';
    }
    if (lower == 'help' || lower == 'what can you do') {
      return 'I can chat by text or voice. Calls, messages, and opening other apps require additional platform integrations and your permission.';
    }
    return null;
  }

  Future<String> _askBackend(String prompt) async {
    final response = await http.post(
      Uri.parse('$backendBaseUrl/chat'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'message': prompt, 'language': _localeId}),
    ).timeout(const Duration(seconds: 60));
    if (response.statusCode != 200) throw Exception('Backend HTTP ${response.statusCode}: ${response.body}');
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return data['reply'] as String? ?? 'I did not receive a reply.';
  }

  Future<void> _send() async {
    final prompt = _input.text.trim();
    if (prompt.isEmpty || _busy) return;
    setState(() {
      _messages.add(ChatMessage(role: 'user', text: prompt));
      _input.clear();
      _busy = true;
    });
    _jumpToBottom();
    try {
      final answer = await _localCommand(prompt) ?? await _askBackend(prompt);
      if (!mounted) return;
      setState(() => _messages.add(ChatMessage(role: 'assistant', text: answer)));
      _jumpToBottom();
      await _tts.setLanguage(_localeId);
      await _tts.speak(answer);
    } catch (e) {
      if (!mounted) return;
      setState(() => _messages.add(ChatMessage(
        role: 'assistant',
        text: 'Could not connect to AI service. Check the backend URL and server. Details: $e',
      )));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _show(String message) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _jumpToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    _speech.stop();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final selected = _languages.entries.firstWhere((e) => e.value == _localeId).key;
    return Scaffold(
      appBar: AppBar(
        title: const Text('MAHEE DU AI'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: DropdownButton<String>(
              value: _localeId,
              underline: const SizedBox.shrink(),
              items: _languages.entries.map((e) => DropdownMenuItem(value: e.value, child: Text(e.key))).toList(),
              onChanged: _changeLanguage,
            ),
          )
        ],
      ),
      body: SafeArea(child: Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          child: Text('Voice assistant • $selected • Tap the microphone to speak', style: Theme.of(context).textTheme.bodySmall),
        ),
        Expanded(child: ListView.builder(
          controller: _scroll,
          padding: const EdgeInsets.all(16),
          itemCount: _messages.length,
          itemBuilder: (context, index) {
            final item = _messages[index];
            final isUser = item.role == 'user';
            return Align(
              alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                constraints: const BoxConstraints(maxWidth: 560),
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                decoration: BoxDecoration(
                  color: isUser ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(item.text),
              ),
            );
          },
        )),
        if (_busy) const LinearProgressIndicator(),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: Row(children: [
            IconButton.filledTonal(
              tooltip: _listening ? 'Stop listening' : 'Speak',
              onPressed: _listening ? _stopListening : _startListening,
              icon: Icon(_listening ? Icons.stop : Icons.mic),
            ),
            const SizedBox(width: 8),
            Expanded(child: TextField(
              controller: _input,
              minLines: 1,
              maxLines: 4,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _send(),
              decoration: const InputDecoration(hintText: 'Talk to MAHEE DU…', border: OutlineInputBorder()),
            )),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: _busy ? null : _send, icon: const Icon(Icons.send), tooltip: 'Send'),
          ]),
        )
      ])),
    );
  }
}
