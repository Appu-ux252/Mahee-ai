# MAHEE DU AI — Cross-platform starter

Flutter client + FastAPI backend starter for Android, iOS, Windows, and macOS.

## Included
- Text chat via backend AI API
- Tap-to-talk speech recognition where supported
- Spoken responses via the device's text-to-speech engine
- Language selector: English, Sinhala, Tamil
- Basic safe local commands ("help", "stop speaking")
- Platform permission notes

## Not yet implemented
Unrestricted app control, direct calls, direct SMS/WhatsApp sending, and continuous always-on listening are NOT implemented. These need separate OS-specific integration, permission handling, and user confirmation. A language selection does not guarantee Sinhala/Tamil speech recognition or a particular female voice on every device.

## Backend
Python 3.10+ recommended.

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in the environment. Never put the API key in Flutter.
```bash
# macOS/Linux
export OPENAI_API_KEY="YOUR_API_KEY"
export OPENAI_MODEL="gpt-4o-mini"
# Windows PowerShell
$env:OPENAI_API_KEY="YOUR_API_KEY"
$env:OPENAI_MODEL="gpt-4o-mini"
```
Start server:
```bash
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

## Flutter
Install Flutter SDK and run `flutter doctor`, then:
```bash
cd flutter_app
flutter create . --platforms=android,ios,windows,macos
flutter pub get
```
The command generates platform runner folders. Merge permission snippets from `docs/PLATFORM_PERMISSIONS.md` into the generated platform files.

Edit `backendBaseUrl` in `lib/main.dart`:
- Android emulator: `http://10.0.2.2:8000`
- iOS simulator / desktop on same computer: `http://127.0.0.1:8000`
- Physical phone: `http://YOUR_COMPUTER_LAN_IP:8000` (same Wi-Fi, firewall configured)

Then run on a supported development machine:
```bash
flutter run -d android
flutter run -d ios
flutter run -d windows
flutter run -d macos
```
iOS requires macOS + Xcode. Windows desktop builds require Windows + Visual Studio C++ workload.

## Production requirements
Use HTTPS, authentication, rate limits, privacy disclosures, and platform-specific tests. Ask before sending messages, placing calls, or sharing private data.
