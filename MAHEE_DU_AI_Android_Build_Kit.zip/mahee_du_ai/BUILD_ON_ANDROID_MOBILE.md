# Build MAHEE DU APK using only an Android phone

This project now includes a GitHub Actions workflow that can compile an Android APK in GitHub's cloud build environment. You do not need to install Flutter on your phone.

## Important limits
- The workflow builds the Flutter app into an APK. It does not host the AI backend.
- The app currently points to `http://127.0.0.1:8000`, which means the phone itself; AI chat will not connect unless you change `backendBaseUrl` in `flutter_app/lib/main.dart` to a reachable backend HTTPS URL.
- Never put an OpenAI API key inside the Flutter app or publish it to GitHub. Keep it on a secured backend.
- Voice input/output depends on Android permissions and installed language/voice services. It cannot guarantee a female voice for every language/device.

## Phone-only build steps
1. Sign in or create a GitHub account in your phone browser.
2. Create a new repository named `mahee-du-ai` and keep it private if desired.
3. Extract the ZIP on your phone, then upload the project files and folders to the repository. Make sure the `.github/workflows/build-android-apk.yml` file is included. If the mobile upload interface does not allow folders, use GitHub's web editor or a Git client app that can upload folders.
4. Open the repository's **Actions** tab.
5. Select **Build MAHEE DU Android APK** and tap **Run workflow**. If it is not shown, commit/push the workflow file to the `main` branch first.
6. When the run finishes successfully, open that run, scroll to **Artifacts**, and download `mahee-du-android-apk`.
7. Extract the downloaded artifact ZIP. Tap `app-release.apk` to install it. Android may ask you to allow installs from that browser/file manager; only proceed with your own build.

## To enable AI chat
Host `backend/app.py` on a secure backend service, configure `OPENAI_API_KEY` as a server-side secret, then change `backendBaseUrl` to that backend's HTTPS address and rebuild the APK. Do not share your API key in chat or commit it to the repository.
