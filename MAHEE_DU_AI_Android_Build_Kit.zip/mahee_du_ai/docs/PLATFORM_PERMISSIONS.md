# Platform permissions and integration notes

These snippets are not a claim that all device actions are implemented.

## Android
After generating platform folders, add inside `android/app/src/main/AndroidManifest.xml`, under `<manifest>`:

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.INTERNET" />
```

Test runtime microphone permission and installed speech services. Prefer HTTPS. For local development, Android cleartext HTTP can be blocked depending on configuration; do not enable it broadly in production.

For calls, prefer opening the system dialer with a `tel:` URI so the user confirms. Direct calling and direct SMS need additional sensitive permissions and distribution-policy review. For WhatsApp, use supported share/deep-link flows; unrestricted automation is not available.

## iOS
Add to `ios/Runner/Info.plist`:

```xml
<key>NSMicrophoneUsageDescription</key>
<string>MAHEE DU uses the microphone when you tap the voice button.</string>
<key>NSSpeechRecognitionUsageDescription</key>
<string>MAHEE DU converts your speech to text to answer your request.</string>
```

iOS does not allow arbitrary control of other apps or silent sending of messages. Use supported system composer flows and user confirmation.

## Windows
Build on Windows with Flutter and the Visual Studio C++ desktop workload. Microphone and speech recognition availability depends on plugin support and Windows speech services.

## macOS
Build on macOS with Xcode. Add microphone and speech-recognition usage descriptions to `macos/Runner/Info.plist` if required by the chosen plugins. Check App Sandbox entitlements for microphone and network access.

## Voice
`flutter_tts` can request a locale but cannot guarantee a female voice. Available voices and Sinhala/Tamil support depend on the OS. For consistent multilingual voice, consider a licensed cloud TTS service on the backend and disclose cloud processing.

## Before production
Use HTTPS, authentication, rate limits, privacy disclosures, a clear microphone indicator, and platform-specific testing. Require confirmation before sending messages, placing calls, or sharing private data.
